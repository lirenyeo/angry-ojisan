
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/angrify.mjs
var GEMINI_KEY = process.env.GEMINI_API_KEY || "";
var HAS_GEMINI = Boolean(GEMINI_KEY);
var GEMINI_IMAGE_MODEL = process.env.GEMINI_IMAGE_MODEL || "gemini-3.1-flash-image";
var ALLOWED_MEDIA = /* @__PURE__ */ new Set(["image/jpeg", "image/png", "image/webp"]);
var MAX_IMAGE_BYTES = 5 * 1024 * 1024;
var CHROMA = "a perfectly uniform, flat, solid chroma-key green background (pure RGB 0,255,0), with absolutely no green anywhere on the person";
var REALISM = "Keep this a realistic photograph of the SAME real person \u2014 do NOT cartoonify, stylize, illustrate or repaint them; preserve their real hair, glasses, skin texture and natural photographic lighting. It must still look like an actual photo of them.";
var GEMINI_CALM_PROMPT = "Edit this photo. " + REALISM + " Cut out just their head, neck and the very top of their shoulders, centered, on " + CHROMA + ". Keep a calm, neutral expression. Photorealistic, square framing.";
var GEMINI_ANGRY_PROMPT = "Edit this photo. " + REALISM + " Cut out just their head, neck and the very top of their shoulders, centered, on " + CHROMA + ". Change ONLY their expression to comically, over-the-top FURIOUS: deeply furrowed V-shaped eyebrows, intense glaring eyes, gritted teeth or an open shouting mouth, and flushed red cheeks \u2014 exaggerated and funny, but still a real photo of them, never gory or scary. Keep the same hair, glasses, skin tone and framing. Photorealistic, square framing.";
var GEMINI_TIMEOUT_MS = 9e3;
var RATE_LIMIT = 10;
var hits = /* @__PURE__ */ new Map();
function rateLimited(ip) {
  if (hits.size > 5e3) hits.clear();
  const now = Date.now();
  const windowStart = now - 6e4;
  const list = (hits.get(ip) || []).filter((t) => t > windowStart);
  if (list.length >= RATE_LIMIT) {
    hits.set(ip, list);
    return true;
  }
  list.push(now);
  hits.set(ip, list);
  return false;
}
async function geminiCutout(mediaType, data, angry) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_IMAGE_MODEL}:generateContent`;
  const body = JSON.stringify({
    contents: [
      {
        role: "user",
        parts: [
          { inline_data: { mime_type: mediaType, data } },
          { text: angry ? GEMINI_ANGRY_PROMPT : GEMINI_CALM_PROMPT }
        ]
      }
    ],
    generationConfig: { responseModalities: ["IMAGE"] }
  });
  try {
    const resp = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": GEMINI_KEY },
      signal: AbortSignal.timeout(GEMINI_TIMEOUT_MS),
      body
    });
    if (!resp.ok) {
      const detail = await resp.text().catch(() => "");
      console.error(`gemini http ${resp.status} (${angry ? "angry" : "calm"})`, detail.slice(0, 200));
      return null;
    }
    const json = await resp.json();
    const parts = json?.candidates?.[0]?.content?.parts || [];
    for (const p of parts) {
      const inline = p.inlineData || p.inline_data;
      if (inline?.data) {
        const mt = inline.mimeType || inline.mime_type || "image/png";
        return `data:${mt};base64,${inline.data}`;
      }
    }
    console.warn(
      `gemini no image (${angry ? "angry" : "calm"}) finishReason=${json?.candidates?.[0]?.finishReason}`
    );
  } catch (err) {
    console.error(`gemini error (${angry ? "angry" : "calm"})`, err?.name || "", err?.message || "");
  }
  return null;
}
var reply = (obj, status = 200) => new Response(JSON.stringify(obj), {
  status,
  headers: { "Content-Type": "application/json" }
});
var angrify_default = async (req, context) => {
  if (req.method !== "POST") return reply({ ok: false, reason: "method" }, 405);
  const ip = context?.ip || req.headers.get("x-nf-client-connection-ip") || "unknown";
  if (rateLimited(ip)) return reply({ ok: false, reason: "rate_limited" }, 429);
  let payload;
  try {
    payload = await req.json();
  } catch {
    return reply({ ok: false, reason: "bad_request" }, 400);
  }
  const image = payload?.image;
  if (typeof image !== "string") return reply({ ok: false, reason: "bad_request" }, 400);
  const match = image.match(/^data:(image\/jpeg|image\/png|image\/webp);base64,([A-Za-z0-9+/=]+)$/);
  if (!match || !ALLOWED_MEDIA.has(match[1])) return reply({ ok: false, reason: "bad_image" }, 400);
  const [, mediaType, data] = match;
  if (data.length * 0.75 > MAX_IMAGE_BYTES) return reply({ ok: false, reason: "too_large" }, 413);
  if (!HAS_GEMINI) return reply({ ok: false, reason: "no_api_key" });
  const [calm, angry] = await Promise.all([
    geminiCutout(mediaType, data, false),
    geminiCutout(mediaType, data, true)
  ]);
  if (calm && angry) return reply({ ok: true, kind: "cutout", calm, angry });
  console.warn(`gemini cutout incomplete (calm:${!!calm} angry:${!!angry})`);
  return reply({ ok: false, reason: "image_failed" }, 502);
};
var config = { path: "/api/angrify" };
export {
  config,
  angrify_default as default
};
